import SwiftUI
import AVFoundation




struct ContentView: View {
   @State var textToSpeech = ""
    //holds the entered text to be given to the button 
    let synthesizer = AVSpeechSynthesizer() 
    //debugging: persistent instance so it works omg
    var body: some View {
        VStack(spacing: 20){
          
            TextField("Enter Text To Speak",text: $textToSpeech)
                .padding()
            .textFieldStyle(RoundedBorderTextFieldStyle()) 
            .foregroundColor(.black)
            //the textfield input as what to speak 
        Button("Tap To Speak") {
        let cleanedText = textToSpeech.trimmingCharacters(in: .whitespacesAndNewlines)
            if cleanedText.isEmpty {
                print("theres nothing here to speak")
                return
            //debugging: omg the code works right??
            //no only works once. useing 
                //copilot is really helpful for debugging the code.
                        }
            let utterance = AVSpeechUtterance(string: cleanedText)
            utterance.rate = AVSpeechUtteranceDefaultSpeechRate
            synthesizer.speak(utterance)            //omfg it works, i think i declared utterance wrong oh well it works now.
            
            print("Speaking : \(textToSpeech)")
            return
                    }      
            //the button that speaks the text, the meat of the code so to speak.
        .foregroundColor(.black)
            
        }
                        
            
        
    }
}
